function [] = runFunct(in,wTorq)

    % Set Boundary behaviours.
    k = 2.5*in/16;
    wTorq0 = -2*wTorq;
    
    main

end

